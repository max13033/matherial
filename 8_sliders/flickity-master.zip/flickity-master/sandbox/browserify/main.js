var Flickity = require('../../js/index');

new Flickity('#gallery');
